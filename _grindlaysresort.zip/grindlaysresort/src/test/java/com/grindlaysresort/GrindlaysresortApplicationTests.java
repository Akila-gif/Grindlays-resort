package com.grindlaysresort;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrindlaysresortApplicationTests {

	@Test
	void contextLoads() {
	}

}
